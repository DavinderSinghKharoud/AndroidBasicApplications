package com.example.android.listview;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    int[]IMAGES={R.drawable.cloudy,R.drawable.rainh,R.drawable.freezingrain,R.drawable.lightning,R.drawable.sunny,R.drawable.cloudy,R.drawable.rainh,R.drawable.freezingrain,R.drawable.lightning,R.drawable.sunny
    };
    String[]NAMES={"India","Canada","Russia","Europe","China","punjab","Patiala","Nepal","Spain","Quebec"
    };
    String[]DESCRIPTIONS={
            "Cloudy","Heavy Rain","Snow","Lightning","Sunny","Cloudy","Heavy Rain","Snow","Lightning","Sunny"
    };
    int[]Temp={
      20,26,-4,23,35,15,27,-7,25,40
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView listView=(ListView)findViewById(R.id.TestingView);
        CustomAdapter customAdapter=new CustomAdapter();
        listView.setAdapter(customAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Intent intent=new Intent(MainActivity.this,SecondActivity.class);
                    Bundle Allvalues=new Bundle();
                    Allvalues.putString("CityName",NAMES[position]);
                    Allvalues.putString("Images", String.valueOf(IMAGES[position]));
                    Allvalues.putString("temp",String.valueOf(Temp[position]));
                    Allvalues.putString("descriptions",DESCRIPTIONS[position]);
                    intent.putExtras(Allvalues);
                    startActivity(intent);

            }
        });

    }

    class CustomAdapter extends BaseAdapter{

        @Override
        public int getCount() {
            return IMAGES.length;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            convertView=getLayoutInflater().inflate(R.layout.cutomlayout,null);
            ImageView imageView=(ImageView)convertView.findViewById(R.id.Images);
            TextView textView=(TextView)convertView.findViewById(R.id.names);
            TextView textView1=(TextView)convertView.findViewById(R.id.Desciptions);
            TextView textView2=(TextView)convertView.findViewById(R.id.temperature);

            imageView.setImageResource(IMAGES[position]);
            textView.setText(NAMES[position]);
            textView1.setText(DESCRIPTIONS[position]);
            textView2.setText(String.valueOf(Temp[position]));
            return convertView;
        }
    }
}
