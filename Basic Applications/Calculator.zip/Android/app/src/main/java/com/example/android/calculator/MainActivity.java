package com.example.android.calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Button Dot, one, two, three, four, five, six, seven, eight, nine, zero, equal, divide, multiply, minus, add,clear;
    EditText user;
    boolean mAddition, mSubtraction, mMultiplication, mDividing;
    private Double value1, value2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Dot = (Button) findViewById(R.id.buttDot);
        one = (Button) findViewById(R.id.butt1);
        two = (Button) findViewById(R.id.butt2);
        three = (Button) findViewById(R.id.butt3);
        four = (Button) findViewById(R.id.butt4);
        five = (Button) findViewById(R.id.butt5);
        six = (Button) findViewById(R.id.butt6);
        seven = (Button) findViewById(R.id.butt7);
        eight = (Button) findViewById(R.id.butt8);
        nine = (Button) findViewById(R.id.butt9);
        zero = (Button) findViewById(R.id.butt0);
        user = (EditText) findViewById(R.id.editText);
        add=(Button)findViewById(R.id.buttAdd);
        minus=(Button)findViewById(R.id.buttMinus);
        multiply=(Button)findViewById(R.id.buttMultiply);
        divide=(Button)findViewById(R.id.buttDivide);
        equal=(Button)findViewById(R.id.buttEqual);
        clear=(Button)findViewById(R.id.buttClear);
        Dot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setEditText(user.getText() + ".");
            }
        });
        zero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setEditText(user.getText() + "0");
            }
        });

        one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setEditText(user.getText() + "1");
            }
        });
        two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setEditText(user.getText() + "2");
            }
        });
        three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setEditText(user.getText() + "3");
            }
        });
        four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setEditText(user.getText() + "4");
            }
        });
        five.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setEditText(user.getText() + "5");
            }
        });
        six.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setEditText(user.getText() + "6");
            }
        });
        seven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setEditText(user.getText() + "7");
            }
        });
        eight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setEditText(user.getText() + "8");
            }
        });
        nine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setEditText(user.getText() + "9");
            }
        });
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (user.getText().toString().isEmpty()) {
                    user.setText(null);
                } else {
                    value1 = Double.parseDouble(user.getText().toString() + "");
                    mAddition = true;
                    user.setText(null);
                }

            }
        });
        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (user.getText().toString().isEmpty()) {
                    user.setText(null);
                } else {
                    value1 = Double.parseDouble(user.getText().toString() + "");
                    mSubtraction = true;
                    user.setText(null);
                }

            }
        });
        multiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (user.getText().toString().isEmpty()) {
                    user.setText(null);
                } else {
                    value1 = Double.parseDouble(user.getText().toString() + "");
                    mMultiplication = true;
                    user.setText(null);
                }

            }
        });
        divide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (user.getText().toString().isEmpty()) {
                    user.setText(null);
                } else {
                    value1 = Double.parseDouble(user.getText().toString() + "");
                    mDividing = true;
                    user.setText(null);
                }

            }
        });
        equal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                value2 = Double.parseDouble(user.getText().toString() + "");
                if (mAddition == true) {
                    user.setText(value1 + value2 + "");
                    mAddition = false;
                }else if(mSubtraction==true){
                    user.setText(value1 - value2 + "");
                    mSubtraction = false;
                }else if(mMultiplication==true){
                    user.setText(value1 * value2 + "");
                    mMultiplication = false;
                }
                else if(mDividing==true){
                    user.setText(value1 / value2 + "");
                    mDividing = false;
                }

            }
        });
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               String a=user.getText().toString();
               if(a.length()<1){

               }else {
                   a = a.substring(0, a.length() - 1);
                   user.setText(a);
               }
            }
        });
        clear.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                user.setText(null);
                mAddition=false;
                mDividing=false;
                mMultiplication=false;
                mSubtraction=false;
                return true;
            }
        });
    }

    public void setEditText(String number){
        user.setText(number);
    }
}

