package com.example.android.listview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        Bundle AllValues=getIntent().getExtras();
        String cityName=AllValues.getString("CityName");
        String ImagesID=AllValues.getString("Images");
        String temperature=AllValues.getString("temp");
        String descriptions=AllValues.getString("descriptions");
        TextView textView=(TextView)findViewById(R.id.textView);
        ImageView imageView=(ImageView)findViewById(R.id.imageView);
        TextView textView1=(TextView)findViewById(R.id.tempSet);
        TextView textView2=(TextView)findViewById(R.id.weather);
        imageView.setImageResource(Integer.valueOf(ImagesID));
        textView.setText(cityName);
        textView1.setText(temperature);
        textView2.setText(descriptions);
    }
}
